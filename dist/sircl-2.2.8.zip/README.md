﻿Sircl
=====

Sircl is a Javascript(/CSS) library to support server-side rendering.

The library facilitates developing web applications with server-side rendering as with ASP.NET MVC, Java Servlets and JSP, PHP, etc, by eliminating most needs for client-side scripting while offering a fluent, rich, "multi-page" or "single-page" experience to endusers.

See: https://www.getsircl.com/

Sourcecode: https://github.com/codetuner/Sircl2
