﻿// Initialize sircl lib:
if (typeof sircl === "undefined") console.warn("The 'sircl-fa' component should be registered after the 'sircl' component. Please review order of script files.");

// Use a Font Awesome spinner:
sircl.html_spinner = '<i class="sircl-spinner fa-solid fas fa fa-circle-o-notch fa-circle-notch fa-spin"></i> ';

// CodePen FA4: https://codepen.io/codetuner-the-lessful/pen/MWLXgMy
// CodePen FA5: https://codepen.io/codetuner-the-lessful/pen/bGzKbyP
// CodePen FA6: https://codepen.io/codetuner-the-lessful/pen/oNmyvRE
