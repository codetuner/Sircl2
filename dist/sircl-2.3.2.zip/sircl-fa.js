﻿// Initialize sircl lib:
if (typeof sircl === "undefined") console.warn("The 'sircl-fa' component should be registered after the 'sircl' component. Please review order of script files.");

// Use a Font Awesome spinner:
sircl.html_spinner = '<i class="sircl-spinner fas fa-circle-notch fa-spin"></i> ';
